package com.main.milan.responseclass;

public class DataPayloadAssist {
    String name;
}
