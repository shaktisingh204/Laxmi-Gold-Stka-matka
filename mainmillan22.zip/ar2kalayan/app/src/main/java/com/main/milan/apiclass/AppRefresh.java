package com.main.milan.apiclass;

public interface AppRefresh {
    void recall();
}
